import React from 'react'
import ReactDOM from 'react-dom/client'
import MCAAsesoriasPage from './MCAAsesoriasPage'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MCAAsesoriasPage />
  </React.StrictMode>
)