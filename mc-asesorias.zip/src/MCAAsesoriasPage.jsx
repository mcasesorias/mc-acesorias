import React from "react";

export default function MCAAsesoriasPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-100 to-red-100 p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold text-blue-800">MC Asesorías</h1>
        <p className="text-lg text-red-700 mt-2">
          Trámites seguros y personalizados para tu visa americana de turismo
        </p>
      </header>

      <section className="max-w-3xl mx-auto bg-white p-6 rounded-2xl shadow-xl">
        <h2 className="text-2xl font-semibold text-blue-800 mb-4">Contáctanos</h2>
        <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input placeholder="Nombre" className="border p-2 rounded border-blue-500" />
          <input placeholder="Apellido" className="border p-2 rounded border-blue-500" />
          <input placeholder="Número de contacto" className="md:col-span-2 border p-2 rounded border-blue-500" />
          <div className="md:col-span-2 flex justify-end gap-4 mt-4">
            <button type="button" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded">Primera Visa</button>
            <button type="button" className="bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded">Renovación</button>
          </div>
        </form>
      </section>

      <section className="mt-12 text-center">
        <h3 className="text-xl font-medium text-blue-800 mb-2">Síguenos</h3>
        <div className="flex justify-center gap-6">
          <a href="https://facebook.com" target="_blank" className="text-blue-600 hover:underline">Facebook</a>
          <a href="https://instagram.com" target="_blank" className="text-red-600 hover:underline">Instagram</a>
          <a href="tel:+50212345678" className="text-green-600 hover:underline">Llamar</a>
        </div>
      </section>
    </main>
  );
}